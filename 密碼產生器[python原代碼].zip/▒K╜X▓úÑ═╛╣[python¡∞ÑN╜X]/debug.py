import os
import time
print("檢查是否安裝colorama模組")
time.sleep(1)
name="colorama"
all=os.popen("pip list").read()
if name in all:
	print("\n已安裝")
	time.sleep(1)
else:
	print("\n未安裝")
	time.sleep(1)
	print("正在安裝colorama...\n")
	time.sleep(1)
	os.system("pip install colorama")
	print("\n[完成]")
	time.sleep(1)