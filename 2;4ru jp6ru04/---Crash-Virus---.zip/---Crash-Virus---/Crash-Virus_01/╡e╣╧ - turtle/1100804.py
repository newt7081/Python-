import time
import turtle as tu
import colorsys as co
import random as ra
# 主程式-------------------------------------------------------->
tu.speed(11)
tu.dot(50)
tu.up()
tu.goto(-200,0)
tu.dot(50)
tu.goto(-100,0)
tu.dot(50)
tu.goto(100,0)
tu.dot(50)
tu.goto(200,0)
tu.dot(50)

a=1
x=-200
tu.up()
while a<=5:
	tu.goto(x,0)
	tu.dot(50,"green")
	x=x+100
	a=a+1

tu.clear()
tu.reset()
x=-200
tu.up()
import os
os.system("start i/test01.py")
for i in range(5):
	tu.goto(x,0)
	tu.dot(50,"green")
	x=x+100

tu.clear()
tu.reset()
tu.up()
for i in range(-200,201,100):
	tu.goto(i,0)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.up()
for i in range(-200,201,100):
	tu.goto(0,i)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.up()
for i in range(-200,201,100):
	tu.goto(i,i)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.speed(11)
# tu.tracer(0)
tu.up()
for x in range(-300,301,3):
	for y in range(-300,301,3):
		tu.goto(x,y)
		tu.dot(2,"green")
# tu.setheading(0)

tu.clear()
tu.reset()
tu.bgcolor("black")
tu.up()
for a in range(0,360,10):
	tu.goto(0,0)
	tu.setheading(a)
	for b in range(10,300,20):
		color=co.hsv_to_rgb(b/1000,1,1)
		tu.color(color)
		tu.fd(20)
		tu.dot(0.05*b)

tu.clear()
tu.reset()
tu.bgcolor("black")
tu.up()
color=["red","orange","yellow"]
for a in range(0,360,10):
	tu.goto(0,0)
	tu.setheading(a)
	for b in range(10,300,20):
		tu.fd(20)
		c=ra.choice(color)
		tu.dot(0.05*b,c)

tu.clear()
tu.reset()
tu.up()
for x in range(-250,251,5):
	y=0.2*x+8
	tu.goto(x,y)
	tu.dot(5,"blue")
tu.clear()
tu.reset()
tu.up()
for x in range(0,251,50):
	y=0.2*x+8
	tu.goto(x,0)
	tu.dot(x/5,"red")
tu.clear()
tu.reset()
tu.up()
a=range(-250,251,50)
for y in a:
	for x in a:
		tu.goto(x,y)
		tu.dot(0.1*abs(x),"green")
tu.clear()
tu.reset()
tu.speed(11)
tu.up()
for x in range(0,1000,4):
	tu.forward(x)
	tu.dot(0.1*x,"red")
	tu.right(190)
tu.speed(11)
tu.dot(50)
tu.up()
tu.goto(-200,0)
tu.dot(50)
tu.goto(-100,0)
tu.dot(50)
tu.goto(100,0)
tu.dot(50)
tu.goto(200,0)
tu.dot(50)

a=1
x=-200
tu.up()
while a<=5:
	tu.goto(x,0)
	tu.dot(50,"green")
	x=x+100
	a=a+1

tu.clear()
tu.reset()
x=-200
tu.up()
for i in range(5):
	tu.goto(x,0)
	tu.dot(50,"green")
	x=x+100

tu.clear()
tu.reset()
tu.up()
import os as t
os.system("start test01.py")
for i in range(-200,201,100):
	tu.goto(i,0)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.up()
for i in range(-200,201,100):
	tu.goto(0,i)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.up()
for i in range(-200,201,100):
	tu.goto(i,i)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.speed(11)
# tu.tracer(0)
tu.up()
for x in range(-300,301,3):
	for y in range(-300,301,3):
		tu.goto(x,y)
		tu.dot(2,"green")
# tu.setheading(0)

tu.clear()
tu.reset()
tu.bgcolor("black")
tu.up()
for a in range(0,360,10):
	tu.goto(0,0)
	tu.setheading(a)
	for b in range(10,300,20):
		color=co.hsv_to_rgb(b/1000,1,1)
		tu.color(color)
		tu.fd(20)
		tu.dot(0.05*b)

tu.clear()
tu.reset()
tu.bgcolor("black")
tu.up()
color=["red","orange","yellow"]
for a in range(0,360,10):
	tu.goto(0,0)
	tu.setheading(a)
	for b in range(10,300,20):
		tu.fd(20)
		c=ra.choice(color)
		tu.dot(0.05*b,c)

tu.clear()
tu.reset()
tu.up()
for x in range(-250,251,5):
	y=0.2*x+8
	tu.goto(x,y)
	tu.dot(5,"blue")
tu.clear()
tu.reset()
tu.up()
for x in range(0,251,50):
	y=0.2*x+8
	tu.goto(x,0)
	tu.dot(x/5,"red")
tu.clear()
tu.reset()
tu.up()
a=range(-250,251,50)
for y in a:
	for x in a:
		tu.goto(x,y)
		tu.dot(0.1*abs(x),"green")
tu.clear()
tu.reset()
tu.speed(11)
tu.up()
for x in range(0,1000,4):
	tu.forward(x)
	tu.dot(0.1*x,"red")
	tu.right(190)
tu.speed(11)
tu.dot(50)
tu.up()
tu.goto(-200,0)
tu.dot(50)
tu.goto(-100,0)
tu.dot(50)
tu.goto(100,0)
tu.dot(50)
tu.goto(200,0)
tu.dot(50)

a=1
x=-200
tu.up()
while a<=5:
	tu.goto(x,0)
	tu.dot(50,"green")
	x=x+100
	a=a+1

tu.clear()
tu.reset()
x=-200
tu.up()
for i in range(5):
	tu.goto(x,0)
	tu.dot(50,"green")
	x=x+100

tu.clear()
tu.reset()
tu.up()
import os as t
os.system("start test01.py")
for i in range(-200,201,100):
	tu.goto(i,0)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.up()
for i in range(-200,201,100):
	tu.goto(0,i)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.up()
for i in range(-200,201,100):
	tu.goto(i,i)
	tu.dot(50,"green")

tu.clear()
tu.reset()
tu.speed(11)
# tu.tracer(0)
tu.up()
for x in range(-300,301,3):
	for y in range(-300,301,3):
		tu.goto(x,y)
		tu.dot(2,"green")
# tu.setheading(0)

tu.clear()
tu.reset()
tu.bgcolor("black")
tu.up()
for a in range(0,360,10):
	tu.goto(0,0)
	tu.setheading(a)
	for b in range(10,300,20):
		color=co.hsv_to_rgb(b/1000,1,1)
		tu.color(color)
		tu.fd(20)
		tu.dot(0.05*b)

tu.clear()
tu.reset()
tu.bgcolor("black")
tu.up()
color=["red","orange","yellow"]
for a in range(0,360,10):
	tu.goto(0,0)
	tu.setheading(a)
	for b in range(10,300,20):
		tu.fd(20)
		c=ra.choice(color)
		tu.dot(0.05*b,c)

tu.clear()
tu.reset()
tu.up()
for x in range(-250,251,5):
	y=0.2*x+8
	tu.goto(x,y)
	tu.dot(5,"blue")
tu.clear()
tu.reset()
tu.up()
for x in range(0,251,50):
	y=0.2*x+8
	tu.goto(x,0)
	tu.dot(x/5,"red")
tu.clear()
tu.reset()
tu.up()
a=range(-250,251,50)
for y in a:
	for x in a:
		tu.goto(x,y)
		tu.dot(0.1*abs(x),"green")
tu.clear()
tu.reset()
tu.speed(11)
tu.up()
for x in range(0,1000,4):
	tu.forward(x)
	tu.dot(0.1*x,"red")
	tu.right(190)