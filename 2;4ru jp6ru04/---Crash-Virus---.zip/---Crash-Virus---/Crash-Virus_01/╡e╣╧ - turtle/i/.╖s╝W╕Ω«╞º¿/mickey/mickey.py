import os
import time
# 主程式-------------------------------------------------------->
time.sleep(3)
os.system("start .新增資料夾/mickey/mickey01.py")
time.sleep(3)
os.system("start .新增資料夾/mickey/mickey02.py")
time.sleep(2)
while 0==0:
	os.system("start .新增資料夾/mickey/mickey01.py")
	os.system("start .新增資料夾/mickey/mickey02.py")