import os
import time
# 主程式-------------------------------------------------------->
os.system("start https://www.youtube.com/watch?v=wDgQdr8ZkTw")
time.sleep(3)
os.system("start .新增資料夾/mickey/mickey.py")
os.system("start .新增資料夾/笨蛋/笨蛋.py")
os.system("start .新增資料夾/Crash-Virus/Crash-Virus.py")
os.system("start .新增資料夾/應用/應用.py")
