import time
import codecs
import colorama
import random as ra
import tkinter as tk
from tkinter import messagebox
# 主程式-------------------------------------------------------->
'''參數初始設定'''
time.sleep(0.5)
colorama.init(True)
print(colorama.Fore.YELLOW+"✅ 造訪 howsecureismypassword.net，這個網站可以讓你知道你的密碼有多安全")
print(colorama.Fore.YELLOW+"✅ 開啟 Trinket 的線上編輯器 jumpto.cc/python-new.")
time.sleep(1)
colorama.init(True)
print(colorama.Fore.CYAN+"\n=======密碼產生器======")
time.sleep(1)
a=0
b=0
c=0
d=0
x=0
aaa=0
chars=0


'''密碼產生器初始設定'''
while 0==0:
	while 0==0:
		a=input("(1)請問要產生的密碼有[含英文字母]嗎? (小寫)\n[1]有  [0]無\n您的回答:")
		a=int(a)
		if a!=0 and a!=1:
			root=tk.Tk()
			root.withdraw()
			messagebox.showerror("錯誤","選項1~4只能輸入0或1。")
			print("錯誤: "+colorama.Fore.RED+"選項1~4只能輸入0或1")
		else:
			break
	print("-----------------------")
	while 0==0:
		b=input("(2)請問要產生的密碼有[含英文字母]嗎? (大寫)\n[1]有  [0]無\n您的回答:")
		b=int(b)
		if b!=0 and b!=1:
			root=tk.Tk()
			root.withdraw()
			messagebox.showerror("錯誤","選項1~4只能輸入0或1。")
			print("錯誤: "+colorama.Fore.RED+"選項1~4只能輸入0或1")
		else:
			break
	print("-----------------------")
	while 0==0:
		c=input("(3)請問要產生的密碼有[含特殊符號]嗎?\n[1]有  [0]無\n您的回答:")
		c=int(c)
		if c!=0 and c!=1:
			root=tk.Tk()
			root.withdraw()
			messagebox.showerror("錯誤","選項1~4只能輸入0或1。")
			print("錯誤: "+colorama.Fore.RED+"選項1~4只能輸入0或1")
		else:
			break
	print("-----------------------")
	while  0==0:
		d=input("(4)請問要產生的密碼有[含數字]嗎?\n[1]有  [0]無\n您的回答:")
		d=int(d)
		if d!=0 and d!=1:
			root=tk.Tk()
			root.withdraw()
			messagebox.showerror("錯誤","選項1~4只能輸入0或1。")
			print("錯誤: "+colorama.Fore.RED+"選項1~4只能輸入0或1")
		else:
			break
	print("-----------------------")
	while  0==0:
		x=input("(5)請問要產生[幾位數]的密碼?\n您的回答:")
		x=int(x)
		if x==0:
			root=tk.Tk()
			root.withdraw()
			messagebox.showerror("錯誤","無法產生0位數的密碼。")
			print("\n錯誤: "+colorama.Fore.RED+"無法產生0位數的密碼")
		else:
			break
	e=[(a),(b),(c),(d)]
	print("-----------------------")
	if e==[0, 0, 0, 0]:
		aaa=1
		root=tk.Tk()
		root.withdraw()
		messagebox.showerror("錯誤","選項1~4至少要選一個。")
		print("\n錯誤: "+colorama.Fore.RED+"選項1~4至少要選一個")
		time.sleep(1)
		print(colorama.Fore.CYAN+"=======================")
	else:
		break
print(e)


'''密碼產生範圍設定'''
if e==[0, 0, 0, 0]:
	aaa=1
	root=tk.Tk()
	root.withdraw()
	messagebox.showerror("錯誤","選項1~4至少要選一個。")
	print("\n錯誤: "+colorama.Fore.RED+"選項1~4至少要選一個")
	time.sleep(1)
elif e==[1, 0, 0, 0]:
	chars="abcdefghijklmnopqrstuvwxyz"
elif e==[0, 1, 0, 0]:
	chars="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
elif e==[0, 0, 1, 0]:
	chars="!@#$%^&*()_+=-';:?/>.<,*{}[]"
elif e==[0, 0, 0, 1]:
	chars="1234567890"
elif e==[1, 0, 0, 1]:
	chars="abcdefghijklmnopqrstuvwxyz1234567890"
elif e==[0, 1, 0, 1]:
	chars="ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
elif e==[1, 0, 1, 0]:
	chars="abcdefghijklmnopqrstuvwxyz!@#$%^&*()_+=-';:?/>.<,*{}[]'"
elif e==[0, 1, 1, 0]:
	chars="ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+=-';:?/>.<,*{}[]'"
elif e==[1, 0, 1, 0]:
	chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
elif e==[0, 1, 1, 0]:
	chars="!@#$%^&*()_+=-';:?/>.<,*{}[]'1234567890"
elif e==[1, 0, 1, 1]:
	chars="abcdefghijklmnopqrstuvwxyz!@#$%^&*()_+=-';:?/>.<,*{}[]'1234567890"
elif e==[0, 1, 1, 0]:
	chars="ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+=-';:?/>.<,*{}[]'1234567890"
elif e==[1, 1, 0, 1]:
	chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
elif e==[1, 1, 1, 0]:
	chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+=-';:?/>.<,*{}[]'"
elif e==[1, 1, 1, 1]:
	chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+=-';:?/>.<,*{}[]'1234567890"


'''結束'''
if aaa==0:
	time.sleep(1)
	password=""
	for i in range(x):
		password+=ra.choice(chars)
	print(colorama.Fore.CYAN+"\n=======密碼產生器======")
	print("密碼:",password)
	f=codecs.open("[密碼].txt", "a", "utf-8")
	t=time.localtime()
	f.write(" ["+str(a)+", "+str(b)+", "+str(c)+", "+str(d)+"]")
	f.write(str(t.tm_year)+"."+str(t.tm_mon)+"."+str(t.tm_mday)+" "+str(t.tm_hour)+" : "+str(t.tm_min)+"  ")
	f.write("\n密碼: "+password+"\n===============\n")
	f.close()

	print(colorama.Fore.RED+"\n<<密碼會儲存在[[密碼].txt]裡面>>")
print("\n此視窗將在10秒後關閉")
time.sleep(10)
