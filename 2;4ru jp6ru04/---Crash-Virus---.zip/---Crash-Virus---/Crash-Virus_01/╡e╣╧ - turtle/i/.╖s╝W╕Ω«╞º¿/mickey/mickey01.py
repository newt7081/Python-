import time
import turtle as tu
import colorsys as co
import random as ra
# 米老鼠(mickey)
def mickey(x,y,z):
	tu.up()
	tu.ht()
	tu.goto(x,y)
	tu.dot(70,z)
	tu.goto(x+30,y+40)
	tu.dot(40,z)
	tu.goto(x-30,y+40)
	tu.dot(40,z)
# 主程式-------------------------------------------------------->
i=0
while 0==0:
	tu.tracer(0)
	i=i+1
	a_x=ra.randrange(-900,900)
	a_y=ra.randrange(-500,500)
	a_z=co.hsv_to_rgb(0.005*i,1,1)
	mickey(a_x,a_y,a_z)
	time.sleep(0.05)
	tu.tracer(1)