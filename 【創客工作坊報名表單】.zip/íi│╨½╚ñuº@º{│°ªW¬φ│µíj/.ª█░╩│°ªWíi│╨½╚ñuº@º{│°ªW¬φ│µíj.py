'''
{pip install selenium}
# 瀏覽器驅動程式網址
Chrome: http://chromedriver.chromium.org/downloads
Firefox: https://github.com/mozilla/geckodriver/releases
'''
# ------------------------------------------------------------>
'''【報名練習表單】'''
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import os
import time
import codecs

'''初始設定'''
# 引入設定
a = open("0驅動路徑.txt")
text0 = a.read()
a.close()
b = open("1網址.txt")
text1 = b.read()
b.close()
c = codecs.open("2姓名.txt", "r", "utf-8")
text2 = c.read()
c.close()
d = codecs.open("3性別.txt", "r", "utf-8")
text3 = d.read()
d.close()
# e = codecs.open("4年齡.txt", "r", "utf-8")
# text4 = e.read()
# e.close()
f = codecs.open("5參加身分.txt", "r", "utf-8")
z = f.read()
f.close()
g = open("6手機號碼.txt")
text6 = g.read()
g.close()
h = open("7E-mail.txt")
text7 = h.read()
h.close()
# i = codecs.open("8任職狀況.txt", "r", "utf-8")
# text8 = i.read()
# i.close()
print(z)
if z!="會員" and z!="非會員":
	print("只能填入會員or非會員")
	while True:
		pass

# 引入chromedriver.exe
chromedriver = text0
os.environ["webdriver.chrome.driver"] = chromedriver
browser = webdriver.Chrome(chromedriver)
# 設定瀏覽器需要開啟的網址
url = text1
browser.get(url)
# 偵測
while True:
	flag = True
	try:
		browser.find_element_by_css_selector("[jsname='OCpkoe']")
	except:
		flag = False

	if flag:
		break
	else:
		browser.refresh()
	time.sleep(0.5)

# ------------------------------------------------------------>
'''第一頁'''
# 選擇
browser.find_element_by_css_selector("[class='appsMaterialWizToggleRadiogroupOffRadio exportOuterCircle']").click()
# 繼續(下一頁)
browser.find_element_by_css_selector("[jsname='OCpkoe']").click()
while True:
	flag = True
	try:
		browser.find_element_by_css_selector("[jsname='M2UYVd']")
	except:
		flag = False

	if flag:
		break
	time.sleep(0.0001)

'''第二頁'''
# 簡答
browser.find_element_by_css_selector("[aria-labelledby='i1']").click()
browser.find_element_by_css_selector("[aria-labelledby='i1']").send_keys(text2)
browser.find_element_by_css_selector("[aria-labelledby='i29']").click()
browser.find_element_by_css_selector("[aria-labelledby='i29']").send_keys(text6)
browser.find_element_by_css_selector("[aria-labelledby='i33']").click()
browser.find_element_by_css_selector("[aria-labelledby='i33']").send_keys(text7)
# 選擇
browser.find_element_by_css_selector("[data-value="+text3+"]").click()
text5 = ""
if z=="非會員":
	text5 = "非會員  \(15歲以上歡迎免費加入\)  tinyurl.com/9vduyjsz"
	browser.find_element_by_css_selector("[data-value='非會員  \(15歲以上歡迎免費加入\)  tinyurl.com/9vduyjsz']").click()
elif z=="會員":
	text5 = "創客基地會員\(已取得 機具研習證書\)"
	browser.find_element_by_css_selector("[data-value='創客基地會員\(已取得 機具研習證書\)']").click()
print(text5)
# 複選
browser.find_element_by_id("i53").click()
browser.find_element_by_id("i56").click()
# 下拉選單
browser.find_element_by_css_selector("[aria-labelledby='i15']").click()
right_click = browser.find_element_by_css_selector("[data-value='55~65歲']")
ActionChains(browser).move_to_element(right_click).perform()
ActionChains(browser).move_by_offset(0, 100).perform()
ActionChains(browser).click().perform()
while True:
	flag = True
	try:
		browser.find_element_by_css_selector("[aria-expanded='true']")
	except:
		flag = False

	if flag:
		time.sleep(0.0001)
	else:
		break


browser.find_element_by_css_selector("[aria-labelledby='i37']").click()
right_click = browser.find_element_by_css_selector("[aria-labelledby='i37']")
ActionChains(browser).move_to_element(right_click).perform()
ActionChains(browser).move_by_offset(0, -10).perform()
ActionChains(browser).click().perform()
while True:
	flag = True
	try:
		browser.find_element_by_css_selector("[aria-expanded='true']")
	except:
		flag = False

	if flag:
		time.sleep(0.0001)
	else:
		break

browser.find_element_by_css_selector("[jsname='M2UYVd']").click()
time.sleep(1)
browser.quit()
os.system("start .自動報名【創客工作坊報名表單】.py")